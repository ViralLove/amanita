# Amanita WooCommerce Plugin

Простой плагин для интеграции WooCommerce с Python-микросервисом Amanita для блокчейн-функционала.

## Установка

1. Скопируйте папку `amanita` в директорию `/wp-content/plugins/`
2. Активируйте плагин в админ-панели WordPress
3. Перейдите в WooCommerce → Amanita для настройки

## Настройка

1. **Python Service URL**: Укажите URL вашего Python-микросервиса (по умолчанию: http://localhost:8000)
2. **API Key**: Опциональный ключ для аутентификации
3. **Debug Mode**: Включите для логирования операций синхронизации

## Использование

1. Перейдите на страницу любого продукта в WooCommerce
2. Найдите метабокс "Amanita Sync" в правой панели
3. Нажмите кнопку "Sync to Amanita"
4. Продукт будет синхронизирован с Python-микросервисом

## Синхронизируемые данные

- Основная информация (название, описание, цена)
- Категории и теги
- Изображения продукта
- Атрибуты и вариации
- Информация о наличии
- Мета-данные

## Структура проекта

```
amanita/
├── amanita.php              # Главный файл плагина
├── admin/
│   ├── MetaBoxes.php        # Метабокс синхронизации
│   └── SettingsPage.php     # Страница настроек
├── includes/
│   ├── SyncProduct.php      # Логика синхронизации продукта
│   ├── SyncOrder.php        # Логика синхронизации заказов (заготовка)
│   ├── HttpClient.php       # HTTP-клиент (заготовка)
│   └── Uninstaller.php      # Очистка при удалении (заготовка)
├── languages/               # Файлы локализации
├── tests/                   # Тесты
└── composer.json           # Зависимости
```

## API Endpoint

Плагин отправляет данные на endpoint: `{python_service_url}/api/products/sync`

### Формат данных

```json
{
  "id": 123,
  "name": "Product Name",
  "description": "Product description",
  "price": "29.99",
  "categories": [...],
  "images": [...],
  "attributes": [...],
  "sync_timestamp": 1234567890,
  "wordpress_site_url": "https://example.com"
}
```

## Разработка

### Добавление новых полей

1. Отредактируйте метод `map_product_data()` в `SyncProduct.php`
2. Добавьте новые поля в массив данных

### Логирование

При включенном debug mode все операции синхронизации записываются в WordPress error log.

### Безопасность

- Проверка nonce для всех форм
- Проверка прав доступа (`manage_woocommerce`)
- Валидация входных данных
- Экранирование вывода

## Требования

- WordPress 5.0+
- WooCommerce 3.0+
- PHP 7.4+

## Лицензия

MIT License 