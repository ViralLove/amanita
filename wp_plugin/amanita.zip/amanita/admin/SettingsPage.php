<?php
/**
 * SettingsPage - страница настроек плагина Amanita
 * 
 * @package Amanita
 */

if (!defined('ABSPATH')) {
    exit;
}

class Amanita_SettingsPage {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'init_settings'));
    }
    
    /**
     * Добавляет страницу настроек в админ-меню
     */
    public function add_settings_page() {
        add_submenu_page(
            'woocommerce',
            'Amanita Settings',
            'Amanita',
            'manage_woocommerce',
            'amanita-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Инициализирует настройки
     */
    public function init_settings() {
        register_setting('amanita_settings', 'amanita_python_service_url');
        register_setting('amanita_settings', 'amanita_api_key');
        register_setting('amanita_settings', 'amanita_debug_mode');
        register_setting('amanita_settings', 'amanita_logging_enabled');
        
        add_settings_section(
            'amanita_general_section',
            'General Settings',
            array($this, 'render_general_section'),
            'amanita-settings'
        );
        
        add_settings_field(
            'amanita_python_service_url',
            'Python Service URL',
            array($this, 'render_url_field'),
            'amanita-settings',
            'amanita_general_section'
        );
        
        add_settings_field(
            'amanita_api_key',
            'API Key',
            array($this, 'render_api_key_field'),
            'amanita-settings',
            'amanita_general_section'
        );
        
        add_settings_field(
            'amanita_debug_mode',
            'Debug Mode',
            array($this, 'render_debug_field'),
            'amanita-settings',
            'amanita_general_section'
        );
        
        add_settings_field(
            'amanita_logging_enabled',
            'Enable Logging',
            array($this, 'render_logging_field'),
            'amanita-settings',
            'amanita_general_section'
        );
    }
    
    /**
     * Рендерит страницу настроек
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Amanita Settings</h1>
            
            <form method="post" action="options.php">
                <?php
                settings_fields('amanita_settings');
                do_settings_sections('amanita-settings');
                submit_button();
                ?>
            </form>
            
            <div class="amanita-settings-info">
                <h3>About Amanita Integration</h3>
                <p>
                    This plugin synchronizes WooCommerce products with the Amanita Python microservice 
                    for blockchain integration and decentralized commerce features.
                </p>
                
                <h4>How it works:</h4>
                <ol>
                    <li>Configure the Python service URL above</li>
                    <li>Go to any product page in WooCommerce</li>
                    <li>Use the "Amanita Sync" metabox to synchronize the product</li>
                    <li>The product data will be sent to the Python microservice</li>
                </ol>
                
                <h4>Data that gets synchronized:</h4>
                <ul>
                    <li>Product basic info (name, description, price)</li>
                    <li>Categories and tags</li>
                    <li>Product images</li>
                    <li>Attributes and variations</li>
                    <li>Stock information</li>
                    <li>Meta data</li>
                </ul>
            </div>
        </div>
        
        <style>
            .amanita-settings-info {
                margin-top: 30px;
                padding: 20px;
                background: #f9f9f9;
                border-left: 4px solid #0073aa;
            }
            .amanita-settings-info h3 {
                margin-top: 0;
            }
            .amanita-settings-info ul, 
            .amanita-settings-info ol {
                margin-left: 20px;
            }
        </style>
        <?php
    }
    
    /**
     * Рендерит секцию общих настроек
     */
    public function render_general_section() {
        echo '<p>Configure the connection to the Amanita Python microservice.</p>';
    }
    
    /**
     * Рендерит поле для URL Python-сервиса
     */
    public function render_url_field() {
        $value = get_option('amanita_python_service_url', 'http://localhost:8000');
        ?>
        <input type="url" 
               name="amanita_python_service_url" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="http://localhost:8000">
        <p class="description">
            The URL of your Amanita Python microservice (e.g., http://localhost:8000)
        </p>
        <?php
    }
    
    /**
     * Рендерит поле для API ключа
     */
    public function render_api_key_field() {
        $value = get_option('amanita_api_key', '');
        ?>
        <input type="password" 
               name="amanita_api_key" 
               value="<?php echo esc_attr($value); ?>" 
               class="regular-text"
               placeholder="Your API key">
        <p class="description">
            Optional API key for authentication with the Python service
        </p>
        <?php
    }
    
    /**
     * Рендерит поле для режима отладки
     */
    public function render_debug_field() {
        $value = get_option('amanita_debug_mode', false);
        ?>
        <label>
            <input type="checkbox" 
                   name="amanita_debug_mode" 
                   value="1" 
                   <?php checked($value, true); ?>>
            Enable debug mode (logs sync operations to error log)
        </label>
        <p class="description">
            When enabled, sync operations will be logged to the WordPress error log
        </p>
        <?php
    }
    
    /**
     * Рендерит поле для включения логирования
     */
    public function render_logging_field() {
        $value = get_option('amanita_logging_enabled', true);
        ?>
        <label>
            <input type="checkbox" 
                   name="amanita_logging_enabled" 
                   value="1" 
                   <?php checked($value, true); ?>>
            Enable detailed logging of sync operations
        </label>
        <p class="description">
            When enabled, all sync operations will be logged with detailed information
        </p>
        <?php
    }
}
