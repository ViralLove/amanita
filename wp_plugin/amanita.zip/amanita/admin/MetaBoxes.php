<?php
/**
 * MetaBoxes - метабоксы для интеграции с Amanita
 * 
 * @package Amanita
 */

if (!defined('ABSPATH')) {
    exit;
}

class Amanita_MetaBoxes {
    
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_sync_metabox'));
        add_action('admin_notices', array($this, 'show_sync_notices'));
    }
    
    /**
     * Добавляет метабокс синхронизации на страницу продукта
     */
    public function add_sync_metabox() {
        add_meta_box(
            'amanita-sync-metabox',
            'Amanita Sync',
            array($this, 'render_sync_metabox'),
            'product',
            'side',
            'high'
        );
    }
    
    /**
     * Рендерит содержимое метабокса синхронизации
     */
    public function render_sync_metabox($post) {
        $product_id = $post->ID;
        $product = wc_get_product($product_id);
        
        if (!$product) {
            echo '<p>Product not found.</p>';
            return;
        }
        
        // Получаем статус последней синхронизации
        $last_sync = get_post_meta($product_id, '_amanita_last_sync', true);
        $sync_status = get_post_meta($product_id, '_amanita_sync_status', true);
        
        // Проверяем, не находится ли синхронизация в процессе
        $is_pending = ($sync_status === 'pending');
        
        ?>
        <div class="amanita-sync-metabox">
            <p>
                <strong>Product:</strong> <?php echo esc_html($product->get_name()); ?><br>
                <strong>SKU:</strong> <?php echo esc_html($product->get_sku() ?: 'N/A'); ?><br>
                <strong>Status:</strong> <?php echo esc_html($product->get_status()); ?>
            </p>
            
            <?php if ($last_sync): ?>
                <p>
                    <strong>Last Sync:</strong><br>
                    <?php echo esc_html(date('Y-m-d H:i:s', $last_sync)); ?><br>
                    <strong>Status:</strong> 
                    <span class="amanita-status-<?php echo esc_attr($sync_status); ?>">
                        <?php echo esc_html(ucfirst($sync_status ?: 'unknown')); ?>
                    </span>
                </p>
            <?php else: ?>
                <p><em>Not synchronized yet.</em></p>
            <?php endif; ?>
            
            <!-- Секция с логами -->
            <div class="amanita-logs-section">
                <h4>Recent Sync Logs</h4>
                <?php
                $logs = Amanita_Logger::get_product_logs($product_id, 5);
                if (!empty($logs)) {
                    echo '<div class="amanita-logs-container">';
                    foreach (array_reverse($logs) as $log) {
                        echo Amanita_Logger::format_log_entry($log);
                    }
                    echo '</div>';
                } else {
                    echo '<p><em>No logs available.</em></p>';
                }
                ?>
            </div>
            
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('amanita_sync_product', 'amanita_nonce'); ?>
                <input type="hidden" name="action" value="amanita_sync_product">
                <input type="hidden" name="product_id" value="<?php echo esc_attr($product_id); ?>">
                
                <p>
                    <button type="submit" name="amanita_sync_product" class="button button-primary button-large" 
                            style="width: 100%;" <?php echo $is_pending ? 'disabled' : ''; ?>>
                        <span class="dashicons dashicons-update"></span>
                        <?php echo $is_pending ? 'Syncing...' : 'Sync to Amanita'; ?>
                    </button>
                </p>
                
                <p class="description">
                    <?php if ($is_pending): ?>
                        <span class="amanita-status-pending">Synchronization in progress...</span>
                    <?php else: ?>
                        This will synchronize the product data with the Amanita Python microservice.
                    <?php endif; ?>
                </p>
            </form>
        </div>
        
        <style>
            .amanita-sync-metabox {
                padding: 10px 0;
            }
            .amanita-status-success {
                color: #46b450;
                font-weight: bold;
            }
            .amanita-status-error {
                color: #dc3232;
                font-weight: bold;
            }
            .amanita-status-pending {
                color: #ffb900;
                font-weight: bold;
            }
            .amanita-logs-section {
                margin: 15px 0;
                padding: 10px;
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 3px;
            }
            .amanita-logs-section h4 {
                margin: 0 0 10px 0;
                font-size: 14px;
            }
            .amanita-logs-container {
                max-height: 200px;
                overflow-y: auto;
                font-size: 12px;
            }
            .amanita-log-entry {
                padding: 5px;
                margin: 2px 0;
                border-left: 3px solid #ddd;
                background: #fff;
            }
            .amanita-log-info {
                border-left-color: #0073aa;
            }
            .amanita-log-warning {
                border-left-color: #ffb900;
            }
            .amanita-log-error {
                border-left-color: #dc3232;
            }
            .amanita-log-debug {
                border-left-color: #666;
            }
        </style>
        <?php
    }
    
    /**
     * Показывает уведомления о результатах синхронизации
     */
    public function show_sync_notices() {
        if (!isset($_GET['amanita_sync_result']) || !isset($_GET['amanita_message'])) {
            return;
        }
        
        $result = sanitize_text_field($_GET['amanita_sync_result']);
        $message = sanitize_text_field(urldecode($_GET['amanita_message']));
        
        $class = ($result === 'success') ? 'notice-success' : 'notice-error';
        $icon = ($result === 'success') ? 'dashicons-yes' : 'dashicons-no';
        
        ?>
        <div class="notice <?php echo esc_attr($class); ?> is-dismissible">
            <p>
                <span class="dashicons <?php echo esc_attr($icon); ?>"></span>
                <strong>Amanita Sync:</strong> <?php echo esc_html($message); ?>
            </p>
        </div>
        <?php
    }
}
