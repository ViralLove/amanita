<?php
/**
 * SyncProduct - простой класс для синхронизации продукта с Python-микросервисом
 * 
 * @package Amanita
 */

if (!defined('ABSPATH')) {
    exit;
}

class Amanita_SyncProduct {
    
    /**
     * Python-микросервис URL
     */
    private $python_service_url;
    
    public function __construct() {
        $this->python_service_url = get_option('amanita_python_service_url', 'http://localhost:8000');
    }
    
    /**
     * Обработчик формы синхронизации продукта
     */
    public function handle_sync_request() {
        if (!isset($_POST['amanita_sync_product']) || !wp_verify_nonce($_POST['amanita_nonce'], 'amanita_sync_product')) {
            Amanita_Logger::error('Security check failed - invalid nonce', array(
                'user_id' => get_current_user_id(),
                'action' => 'sync_request'
            ));
            wp_die('Security check failed');
        }
        
        if (!current_user_can('manage_woocommerce')) {
            Amanita_Logger::error('Insufficient permissions for sync', array(
                'user_id' => get_current_user_id(),
                'action' => 'sync_request'
            ));
            wp_die('Insufficient permissions');
        }
        
        // Rate limiting: максимум 5 попыток синхронизации в минуту
        $user_id = get_current_user_id();
        $rate_limit_key = 'amanita_sync_rate_limit_' . $user_id;
        $rate_limit_data = get_transient($rate_limit_key);
        
        if ($rate_limit_data === false) {
            // Первая попытка
            set_transient($rate_limit_key, array('count' => 1, 'first_attempt' => time()), 60);
        } else {
            $rate_limit_data['count']++;
            
            if ($rate_limit_data['count'] > 5) {
                Amanita_Logger::warning('Rate limit exceeded', array(
                    'user_id' => $user_id,
                    'attempts' => $rate_limit_data['count'],
                    'action' => 'sync_request'
                ));
                wp_die('Rate limit exceeded. Please wait before trying again.');
            }
            
            set_transient($rate_limit_key, $rate_limit_data, 60);
        }
        
        $product_id = intval($_POST['product_id']);
        if (!$product_id) {
            wp_die('Invalid product ID');
        }
        
        // Проверяем, не находится ли синхронизация уже в процессе
        $current_status = get_post_meta($product_id, '_amanita_sync_status', true);
        if ($current_status === 'pending') {
            Amanita_Logger::warning('Duplicate sync attempt - already pending', array(
                'user_id' => get_current_user_id(),
                'product_id' => $product_id,
                'action' => 'sync_request'
            ));
            wp_die('Synchronization already in progress');
        }
        
        // Устанавливаем статус pending перед началом синхронизации
        update_post_meta($product_id, '_amanita_sync_status', 'pending');
        
        // Логируем начало синхронизации
        Amanita_Logger::info('Product sync started', array(
            'user_id' => get_current_user_id(),
            'product_id' => $product_id,
            'action' => 'sync_start'
        ));
        
        $result = $this->sync_product($product_id);
        
        // Сохраняем статус синхронизации в мета-данных продукта
        update_post_meta($product_id, '_amanita_last_sync', current_time('timestamp'));
        update_post_meta($product_id, '_amanita_sync_status', $result['success'] ? 'success' : 'error');
        
        // Логируем результат синхронизации
        if ($result['success']) {
            Amanita_Logger::info('Product sync completed successfully', array(
                'user_id' => get_current_user_id(),
                'product_id' => $product_id,
                'action' => 'sync_success'
            ));
        } else {
            Amanita_Logger::error('Product sync failed', array(
                'user_id' => get_current_user_id(),
                'product_id' => $product_id,
                'action' => 'sync_error',
                'error_message' => $result['message']
            ));
        }
        
        // Редирект обратно на страницу продукта с сообщением
        $redirect_url = add_query_arg(
            array(
                'amanita_sync_result' => $result['success'] ? 'success' : 'error',
                'amanita_message' => urlencode($result['message'])
            ),
            get_edit_post_link($product_id, '')
        );
        
        wp_redirect($redirect_url);
        exit;
    }
    
    /**
     * Синхронизирует продукт с Python-микросервисом
     */
    public function sync_product($product_id) {
        try {
            $product = wc_get_product($product_id);
            if (!$product) {
                return array(
                    'success' => false,
                    'message' => 'Product not found'
                );
            }
            
            // Маппинг WooCommerce → Python-микросервис
            $mapped_data = $this->map_product_data($product);
            
            // Отправка в Python-микросервис
            $response = $this->send_to_python_service($mapped_data);
            
            if ($response['success']) {
                return array(
                    'success' => true,
                    'message' => 'Product synchronized successfully'
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Failed to sync: ' . $response['message']
                );
            }
            
        } catch (Exception $e) {
            Amanita_Logger::error('Sync exception occurred', array(
                'product_id' => $product_id,
                'action' => 'sync_exception',
                'error_message' => $e->getMessage(),
                'error_trace' => $e->getTraceAsString()
            ));
            return array(
                'success' => false,
                'message' => 'Sync error: ' . $e->getMessage()
            );
        }
    }
    
    /**
     * Маппинг данных продукта WooCommerce в формат Python-микросервиса
     */
    private function map_product_data($product) {
        $data = array(
            'id' => $product->get_id(),
            'name' => $product->get_name(),
            'description' => $product->get_description(),
            'short_description' => $product->get_short_description(),
            'price' => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'sale_price' => $product->get_sale_price(),
            'status' => $product->get_status(),
            'type' => $product->get_type(),
            'sku' => $product->get_sku(),
            'stock_quantity' => $product->get_stock_quantity(),
            'stock_status' => $product->get_stock_status(),
            'weight' => $product->get_weight(),
            'dimensions' => array(
                'length' => $product->get_length(),
                'width' => $product->get_width(),
                'height' => $product->get_height()
            ),
            'categories' => $this->get_product_categories($product),
            'tags' => $this->get_product_tags($product),
            'images' => $this->get_product_images($product),
            'attributes' => $this->get_product_attributes($product),
            'meta_data' => $this->get_product_meta($product),
            'sync_timestamp' => current_time('timestamp'),
            'wordpress_site_url' => get_site_url()
        );
        
        return $data;
    }
    
    /**
     * Получение категорий продукта
     */
    private function get_product_categories($product) {
        $categories = array();
        $terms = get_the_terms($product->get_id(), 'product_cat');
        
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $categories[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug
                );
            }
        }
        
        return $categories;
    }
    
    /**
     * Получение тегов продукта
     */
    private function get_product_tags($product) {
        $tags = array();
        $terms = get_the_terms($product->get_id(), 'product_tag');
        
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $tags[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug
                );
            }
        }
        
        return $tags;
    }
    
    /**
     * Получение изображений продукта
     */
    private function get_product_images($product) {
        $images = array();
        
        // Главное изображение
        if ($product->get_image_id()) {
            $image_url = wp_get_attachment_image_url($product->get_image_id(), 'full');
            if ($image_url) {
                $images[] = array(
                    'id' => $product->get_image_id(),
                    'url' => $image_url,
                    'type' => 'main'
                );
            }
        }
        
        // Галерея изображений
        $gallery_ids = $product->get_gallery_image_ids();
        foreach ($gallery_ids as $image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'full');
            if ($image_url) {
                $images[] = array(
                    'id' => $image_id,
                    'url' => $image_url,
                    'type' => 'gallery'
                );
            }
        }
        
        return $images;
    }
    
    /**
     * Получение атрибутов продукта
     */
    private function get_product_attributes($product) {
        $attributes = array();
        $product_attributes = $product->get_attributes();
        
        foreach ($product_attributes as $attribute_name => $attribute) {
            $attributes[] = array(
                'name' => $attribute_name,
                'label' => wc_attribute_label($attribute_name),
                'values' => $attribute->get_options(),
                'visible' => $attribute->get_visible(),
                'variation' => $attribute->get_variation()
            );
        }
        
        return $attributes;
    }
    
    /**
     * Получение мета-данных продукта
     */
    private function get_product_meta($product) {
        $meta_data = array();
        $product_meta = $product->get_meta_data();
        
        foreach ($product_meta as $meta) {
            $meta_data[] = array(
                'key' => $meta->key,
                'value' => $meta->value
            );
        }
        
        return $meta_data;
    }
    
    /**
     * Отправка данных в Python-микросервис
     */
    private function send_to_python_service($data) {
        $url = trailingslashit($this->python_service_url) . 'api/products/sync';
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-Amanita-Source' => 'wordpress',
                'X-Amanita-Version' => '1.0'
            ),
            'body' => json_encode($data),
            'timeout' => 30,
            'data_format' => 'body'
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'HTTP error: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code >= 200 && $status_code < 300) {
            return array(
                'success' => true,
                'message' => 'Success',
                'data' => json_decode($body, true)
            );
        } else {
            return array(
                'success' => false,
                'message' => 'HTTP ' . $status_code . ': ' . $body
            );
        }
    }
}
