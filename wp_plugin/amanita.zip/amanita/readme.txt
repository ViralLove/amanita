=== Amanita Connector ===
Contributors: amanita, eslinko
Tags: blockchain, woocommerce, sync, ipfs, web3
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Интеграция WooCommerce с блокчейном и IPFS через Python Web3 микросервис. Надёжная синхронизация товаров и заказов, Action Scheduler, безопасные REST API, поддержка i18n.

== Description ==
Amanita Connector — плагин для WooCommerce, который синхронизирует товары и заказы с блокчейном (ProductRegistry, Orders) и IPFS через Python Web3 микросервис. Использует Action Scheduler, WP HTTP API, HMAC/JWT, кеширование, централизованное логирование и best practices безопасности.

== Installation ==
1. Скопируйте папку плагина в wp-content/plugins/.
2. Активируйте через админку WordPress.
3. Настройте параметры интеграции на странице настроек Amanita.

== Changelog ==
= 0.1.0 =
* Initial MVP release.

== Upgrade Notice ==
= 0.1.0 =
Первая версия MVP. Для шифрования ключей на старых версиях WP может потребоваться polyfill для WP Secrets API.

== Documentation ==
См. docs/Amanita-Plugin-Architecture.md для архитектуры и user stories.
