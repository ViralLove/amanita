<?php
/*
Plugin Name: Amanita Connector
Text Domain: amanita
Version: 0.1.0
Requires at least: 5.0
Tested up to: 6.5
WC requires at least: 3.0
WC tested up to: 7.0
*/

// Автозагрузка через Composer
if ( file_exists( __DIR__ . '/composer/autoload_real.php' ) ) {
    require_once __DIR__ . '/composer/autoload_real.php';
}

// Проверка наличия WooCommerce
add_action( 'plugins_loaded', function() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="error"><p>' . esc_html__( 'Amanita Connector требует установленный и активированный WooCommerce.', 'amanita' ) . '</p></div>';
        });
        return;
    }
    
    // Основная инициализация плагина
    require_once __DIR__ . '/includes/Logger.php';
    require_once __DIR__ . '/includes/SyncProduct.php';
    require_once __DIR__ . '/includes/SyncOrder.php';
    require_once __DIR__ . '/includes/HttpClient.php';
    require_once __DIR__ . '/admin/SettingsPage.php';
    require_once __DIR__ . '/admin/MetaBoxes.php';
    
    // Инициализация классов
    new Amanita_MetaBoxes();
    new Amanita_SettingsPage();
    
    // Подключение обработчика формы синхронизации
    add_action('admin_post_amanita_sync_product', array(new Amanita_SyncProduct(), 'handle_sync_request'));
});

// Хуки активации/деактивации/удаления
register_activation_hook( __FILE__,  [ 'Amanita\Uninstaller', 'on_activation' ] );
register_deactivation_hook( __FILE__, [ 'Amanita\Uninstaller', 'on_deactivation' ] );
register_uninstall_hook(   __FILE__,  [ 'Amanita\Uninstaller', 'cleanup' ] );

// Локализация
add_action( 'init', function() {
    load_plugin_textdomain( 'amanita', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
});
